package com.test.spring.batch.retry.exception;

@SuppressWarnings("serial")
public class RetryException extends Exception {

}
